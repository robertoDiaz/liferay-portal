var Lang = A.Lang,

    _NAME = 'image-color-filter',

    _NS = 'colorFilter',

    IDENTITY_MATRIX = [
        1, 0, 0, 0, 0,
        0, 1, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 1, 0
    ],

    ImageColorFilter = A.Component.create({

        /**
         * Static property provides a string to identify the class.
         *
         * @property NAME
         * @type String
         * @static
         */
        NAME: _NAME,

        /**
         * Static property provides a string to identify the namespace.
         *
         * @property NS
         * @type String
         * @static
         */
        NS: _NS,

        /**
         * Static property used to define which component it extends.
         *
         * @property EXTENDS
         * @type String
         * @static
         */
        EXTENDS: A.ImageFilter,

        /**
         * Static property used to define the default attribute
         * configuration for the ImageColorFilter.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {

            /**
             * 5x5 transformation matrix
             *
             * @attribute matrix
             * @type Array
             */
            matrix: {
                validator: Lang.isArray,
                value: IDENTITY_MATRIX
            },

            /**
             *
             *
             * @attribute swfCfg
             * @type Object
             */
            swfCfg: {
                readonly: true,
                value: {
                    processFn: 'colorMatrixFilter',
                    params: [
                        'matrix'
                    ]
                }
            }
        },

        prototype: {

            FILTER_LABEL: _NS,

            FILTER_NS: _NS,

            /**
             * Construction logic executed during ImageColorFilter instantiation.
             * Lifecycle.
             *
             * @method initializer
             * @param config
             * @protected
             */
            initializer: function(config) {

            },

            /**
             *
             */
            process: function(bitmapData, cfg) {
                var instance = this;

                var data = bitmapData.data,
                    matrix = instance.get('matrix');

                if (data.length) {
                    for (var i=0; i < data.length; i+=4) {
                            var r = data[i],
                                g = data[i+1],
                                b = data[i+2],
                                a = data[i+3];

                            data[i] = r * matrix[0] + g * matrix[1] + b * matrix[2] + a * matrix[3] + matrix[4];
                            data[i+1] = r * matrix[5] + g * matrix[6] + b * matrix[7] + a * matrix[8] + matrix[9];
                            data[i+2] = r * matrix[10] + g * matrix[11] + b * matrix[12] + a * matrix[13] + matrix[14];
                            data[i+3] = r * matrix[15] + g * matrix[16] + b * matrix[17] + a * matrix[18] + matrix[19];
                    }
                }

                return bitmapData;
            }
        }

    });

A.ImageColorFilter = ImageColorFilter;