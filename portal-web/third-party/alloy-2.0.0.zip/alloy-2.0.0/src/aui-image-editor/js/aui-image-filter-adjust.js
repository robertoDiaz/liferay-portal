var Lang = A.Lang,

    _NAME = 'image-adjust-filter',

    _NS = 'adjustFilter',

    IDENTITY_MATRIX = [
        1, 0, 0, 0, 0,
        0, 1, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 1, 0
    ],

    ImageAdjustFilter = A.Component.create({

        /**
         * Static property provides a string to identify the class.
         *
         * @property NAME
         * @type String
         * @static
         */
        NAME: _NAME,

        /**
         * Static property provides a string to identify the namespace.
         *
         * @property NS
         * @type String
         * @static
         */
        NS: _NS,

        /**
         * Static property used to define which component it extends.
         *
         * @property EXTENDS
         * @type String
         * @static
         */
        EXTENDS: A.ImageColorFilter,

        /**
         * Static property used to define the default attribute
         * configuration for the ImageAdjustFilter.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {

            /**
             *
             */
            brightness: {
                validator: Lang.isNumber,
                value: 0
            },

            /**
             *
             */
            contrast: {
                validator: Lang.isNumber,
                value: 1
            },

            /**
             *
             */
            saturation: {
                validator: Lang.isNumber,
                value: 1
            }
        },

        prototype: {

            FILTER_NS: _NS,

            EDITOR_TEMPLATE: '<div><input id="contrast" min="0" max="2" step="0.01" type="range">Contrast</input><input id="brightness" min="-1" max="1" step="0.01" type="range">Brightness</input><input id="saturation" min="0" max="2" step="0.01" type="range">Saturation</input></div>',

            /**
             * Construction logic executed during ImageAdjustFilter instantiation.
             * Lifecycle.
             *
             * @method initializer
             * @param config
             * @protected
             */
            initializer: function(config) {
                var instance = this;

                instance.after(['brightnessChange', 'contrastChange', 'saturationChange'], instance._calculateColorMatrix, instance);
            },

            /**
             *
             * @method resetEditor
             */
            resetEditor: function() {
                var instance = this,
                    editor = instance.getEditor();

                editor.one('#contrast').val(1);
                editor.one('#brightness').val(0);
                editor.one('#saturation').val(1);
            },

            /**
             *
             */
            _calculateColorMatrix: function(event) {
                var instance = this,
                    matrix = IDENTITY_MATRIX.slice(0),
                    brightness = instance.get('brightness') * 255,
                    contrast = instance.get('contrast'),
                    t = ((1 - contrast) / 2) * 255,
                    saturation = instance.get('saturation'),
                    sr = (1 - saturation) * 0.3086,
                    sg = (1 - saturation) * 0.6094,
                    sb = (1 - saturation) * 0.0820;

                matrix[0] = contrast * (sr + saturation);
                matrix[1] = contrast * sg;
                matrix[2] = contrast * sb;
                matrix[4] = brightness + t;

                matrix[5] = contrast * sr;
                matrix[6] = contrast * (sg + saturation);
                matrix[7] = contrast * sb;
                matrix[9] = brightness + t;

                matrix[10] = contrast * sr;
                matrix[11] = contrast * sg;
                matrix[12] = contrast * (sb + saturation);
                matrix[14] = brightness + t;

                instance.set('matrix', matrix);
            },

            _bindEditorUI: function(editor, host) {
                var instance = this;

                editor.delegate(
                    'change',
                    function(event) {
                        var target = event.currentTarget,
                            prop = target.attr('id'),
                            val = Number(target.val());

                        instance.set(prop, val);
                        host.preview(instance.FILTER_NS);
                    },
                    'input'
                );
            }
        }

    });

A.ImageAdjustFilter = ImageAdjustFilter;