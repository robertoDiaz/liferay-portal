var Lang = A.Lang,

    _NAME  = 'image-grayscale-filter',

    _NS = 'grayscale',

    MATRIX = [
        0.2225, 0.7169, 0.0606, 0, 0,
        0.2225, 0.7169, 0.0606, 0, 0,
        0.2225, 0.7169, 0.0606, 0, 0,
        0, 0, 0, 1, 0,
        0, 0, 0, 0, 0
    ],

    ImageGrayscaleFilter = A.Base.create(_NAME, A.ImageColorFilter, [], {

        FILTER_LABEL: _NS,

        FILTER_NS: _NS,

    }, {
        NS: _NS,

        /**
         * Static property used to define the default attribute
         * configuration for the Palette.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {
            matrix: {
                readOnly: true,
                value: MATRIX
            }
        }
    });

A.ImageGrayscaleFilter = ImageGrayscaleFilter;