var Lang = A.Lang,

    _NAME = 'image-invert-filter',

    _NS = 'invert',

    MATRIX = [
        -1, 0, 0, 0, 255,
        0, -1, 0, 0, 255,
        0, 0, -1, 0, 255,
        0, 0, 0, 1, 0
    ],

    ImageInvertFilter = A.Base.create(_NAME, A.ImageColorFilter, [], {

        FILTER_LABEL: _NS,

        FILTER_NS: _NS,

    }, {
        NS: _NS,

        /**
         * Static property used to define the default attribute
         * configuration for the Palette.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {
            matrix: {
                readOnly: true,
                value: MATRIX
            }
        }
    });

A.ImageInvertFilter = ImageInvertFilter;