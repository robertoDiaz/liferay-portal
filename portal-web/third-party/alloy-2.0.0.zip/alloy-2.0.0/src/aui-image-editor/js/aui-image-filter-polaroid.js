var Lang = A.Lang,

    _NAME = 'image-polaroid-filter',

    _NS = 'polaroid',

    MATRIX = [
        1.438, -0.122, -0.016, 0, 0.03 * 255,
        -0.062, 1.378, -0.016, 0, 0.05 * 255,
        -0.062, -0.122, 1.483, 0, -0.02 * 255,
        0, 0, 0, 1, 0,
        0, 0, 0, 0, 255
    ],

    ImagePolaroidFilter = A.Base.create(_NAME, A.ImageColorFilter, [], {

        FILTER_LABEL: _NS,

        FILTER_NS: _NS,

    }, {
        NS: _NS,

        /**
         * Static property used to define the default attribute
         * configuration for the Palette.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {
            matrix: {
                readOnly: true,
                value: MATRIX
            }
        }
    });

A.ImagePolaroidFilter = ImagePolaroidFilter;