var Lang = A.Lang,

    _NAME = 'image-sepia-filter',

    _NS = 'sepia',

    MATRIX = [
        0.393, 0.769, 0.189, 0, 0,
        0.349, 0.686, 0.168, 0, 0,
        0.272, 0.534, 0.131, 0, 0,
        0, 0, 0, 1, 0,
        0, 0, 0, 0, 0
    ],

    ImageSepiaFilter = A.Base.create(_NAME, A.ImageColorFilter, [], {

        FILTER_LABEL: _NS,

        FILTER_NS: _NS,

    }, {
        NS: _NS,

        /**
         * Static property used to define the default attribute
         * configuration for the Palette.
         *
         * @property ATTRS
         * @type Object
         * @static
         */
        ATTRS: {
            matrix: {
                readOnly: true,
                value: MATRIX
            }
        }
    });

A.ImageSepiaFilter = ImageSepiaFilter;