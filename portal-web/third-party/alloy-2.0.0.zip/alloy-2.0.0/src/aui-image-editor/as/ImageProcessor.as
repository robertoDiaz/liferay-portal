package {
    import flash.display.Bitmap;
    import flash.display.BitmapData;
    import flash.display.Loader;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.external.ExternalInterface;
    import flash.filters.BitmapFilter;
    import flash.filters.BitmapFilterQuality;
    import flash.filters.BlurFilter;
    import flash.filters.ColorMatrixFilter;
    import flash.geom.Matrix;
    import flash.geom.Point;
    import flash.geom.Rectangle;
    import flash.net.URLRequest;
    import flash.utils.ByteArray;

    import mx.graphics.codec.*;
    import mx.utils.Base64Encoder;

    /**
     * A Flash implementation of an ImageProcessor
     */
    public class ImageProcessor extends Sprite {
        protected var _bitmapDataStack:Vector.<BitmapData> = new Vector.<BitmapData>();

        protected var _initialData:BitmapData;
        protected var _currentData:BitmapData;
        protected var _previewData:BitmapData;

        /**
         * Constructor
         */
        public function ImageProcessor() {
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;

            var url:String = stage.loaderInfo.parameters['imageUrl'];
            var urlRequest:URLRequest = new URLRequest(url);

            var loader:Loader = new Loader();
            loader.contentLoaderInfo.addEventListener(Event.COMPLETE, onLoaderComplete);
            loader.load(urlRequest);

            if (ExternalInterface.available) {
                ExternalInterface.addCallback('clear', clear);
                ExternalInterface.addCallback('getImage', getImage);
                ExternalInterface.addCallback('getImageData', getImageData);
                ExternalInterface.addCallback('preview', preview);
                ExternalInterface.addCallback('putImage', putImage);
                ExternalInterface.addCallback('reset', reset);
                ExternalInterface.addCallback('save', save);
            }
        }

        /**
         *
         */
        public function clear():void {
            this.removeChildAt(0);
            this.addChild(new Bitmap(this._currentData));
        }

        /**
         *
         */
        public function getImage():uint {
            this._bitmapDataStack.push(this._previewData.clone());

            return this._bitmapDataStack.length - 1;
        }

        /**
         *
         */
        public function getImageData():String {
            var w:Number = this.width;
            var h:Number = this.height;

            var rect:Rectangle = new Rectangle(0, 0, w, h);

            var enc:PNGEncoder = new PNGEncoder();
            var png:ByteArray = enc.encodeByteArray(this._currentData.getPixels(rect), w, h);

            var enc64:Base64Encoder = new Base64Encoder();
            enc64.insertNewLines = false;
            enc64.encodeBytes(png);

            return 'data:image/png;base64,' + enc64.toString();
        }

        /**
         *
         */
        public function preview(processFn:String, params:Object):void {
            this._previewData = this._currentData.clone();
            this[processFn](this._previewData, params);

            this.removeChildAt(0);
            this.addChild(new Bitmap(this._previewData));
        }

        /**
         *
         */
        public function putImage(image:uint, offsetX:Number, offsetY:Number):void {
            this._currentData = this._previewData = this._bitmapDataStack[image];

            this.removeChildAt(0);
            this.addChild(new Bitmap(this._currentData));
        }

        /**
         *
         */
        public function reset():void {
            this.removeChildAt(0);
            this.addChild(new Bitmap(this._initialData));
        }

        /**
         *
         */
        public function save():int {
            this._bitmapDataStack.push(this._currentData.clone());
            this._currentData = this._previewData;

            return this._bitmapDataStack.length - 1;
        }

        /**
         *
         */
        private function onLoaderComplete(event:Event):void {
            var loader:Loader = event.currentTarget.loader as Loader;

            this._initialData = new BitmapData(loader.width, loader.height);
            this._initialData.draw(loader);

            this.addChild(new Bitmap(this._initialData));

            this._currentData = this._initialData.clone();
            this._previewData = this._initialData.clone();
        }

        /**
         * FILTERS
         *
         * Below appear some simple flash fallback filter implementations
         */

        /**
         * ColorFilter
         */
        public function colorMatrixFilter(bitmapData:BitmapData, params:Object):void {
            var rect:Rectangle = new Rectangle(0, 0, bitmapData.width, bitmapData.height);
            var pt:Point = new Point(0, 0);

            bitmapData.applyFilter(_previewData, rect, pt, new ColorMatrixFilter(params.matrix));
        }

        /**
         * BlurFilter
         */
        public function blurMatrixFilter(bitmapData:BitmapData, params:Object):void {
            var rect:Rectangle = new Rectangle(0, 0, bitmapData.width, bitmapData.height);
            var pt:Point = new Point(0, 0);

            bitmapData.applyFilter(_previewData, rect, pt, new BlurFilter(params.blurX, params.blurY, BitmapFilterQuality.HIGH));
        }

        /**
         * ScaleFilter
         */
        public function scaleMatrixFilter(bitmapData:BitmapData, params:Object):void {
            var scaleMatrix:Matrix = new Matrix(params.scaleX, 0, 0, params.scaleY, ((1 - params.scaleX) / 2) * this._currentData.width, ((1 - params.scaleY) / 2) * this._currentData.height);

            bitmapData.draw(this._currentData, scaleMatrix);
        }
    }
}